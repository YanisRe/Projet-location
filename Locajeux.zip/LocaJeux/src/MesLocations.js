import React, { useState, useEffect } from 'react';

export default function MesLocations() {
  const [selectedJeuLinks, setSelectedJeuLinks] = useState([]);
  const [selectedJeuDetails, setSelectedJeuDetails] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  // Utilisation de l'effet pour récupérer les liens de Pokémon depuis le local storage lors du chargement de la page
  useEffect(() => {
    // Récupérer la liste des liens de Pokémon stockés dans le local storage
    const storedLinks = JSON.parse(localStorage.getItem('selectedJeuLinks')) || [];
    setSelectedJeuLinks(storedLinks);
  }, []);

  // Utilisation de l'effet pour récupérer les détails des Pokémon à partir des liens sélectionnés
  useEffect(() => {
    // Lorsque la liste des liens est mise à jour, effectuez une boucle pour récupérer les caractéristiques des Pokémon à partir de ces liens.
    const fetchDataForSelectedJeuLinks = async () => {
      const details = [];
      for (let i = 0; i < selectedJeuLinks.length; i++) {
        const response = await fetch(selectedJeuLinks[i]);
        if (response.ok) {
          const data = await response.json();
          details.push(data);
        }
      }
      setSelectedJeuDetails(details);
    };

    fetchDataForSelectedJeuLinks();
  }, [selectedJeuLinks]);

  // Fonction pour supprimer un Pokémon de la liste
  const removeJeu = (index) => {
    const updatedLinks = [...selectedJeuLinks];
    updatedLinks.splice(index, 1);
    setSelectedJeuLinks(updatedLinks);
    localStorage.setItem('selectedJeuLinks', JSON.stringify(updatedLinks));
  };

  // Fonction pour supprimer tous les Pokémon de la liste
  const removeAllJeu = () => {
    setSelectedJeuLinks([]);
    setSelectedJeuDetails([]);
    localStorage.removeItem('selectedJeuLinks');
  };

  // Filtrer les Pokémon en fonction du terme de recherche
  const filteredJeu = selectedJeuDetails.filter((Jeu) =>
  Jeu.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  return (
    <div className='Jeu-app'>
      <h1>Mes Locations</h1>

      <div class="input-container">
        <input
          class="input"
          name="text"
          type="text"
          placeholder="Rechercher"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <label class="label" for="input">Insérez le nom d'un jeu</label>
        <div class="topline"></div>
        <div class="underline"></div>
      </div>
      
      <button className="box" onClick={removeAllJeu}>Supprimer tous les jeux de la liste</button>
      
      <ul className='jeu-list'>
        {filteredJeu.map((Jeu, index) => (
          <div className="jeu-card" key={index}>
            <h2>{Jeu.name}</h2>
            <img src={Jeu.sprites.other.dream_world.front_default} alt={Jeu.name} />
            <p>Notes :</p>
            <ul className="notes-list">
              {Jeu.notes.map((type, typeIndex) => (
                <li key={typeIndex}>{type.type.name}</li>
              ))}
            </ul>
            <button className="codepen-button" onClick={() => removeJeu(index)}>
              <span>Supprimer</span>
            </button>
          </div>
        ))}
      </ul>
    </div>
  );
}
