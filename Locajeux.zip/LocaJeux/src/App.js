import './App.css';
import Accueil from './Accueil';
import { Link, Routes, Route } from 'react-router-dom';
import MesLocations from './MesLocations';
import Manette from './Manette.png';
import Trois from './trois.png'; 

export default function App() {
  return (
    <div className="App">
      <nav className="navbar"> 
        <div className="left-side"> 
          <Link to="/"><img src={Manette} alt="Jeux logo" className="logo" /></Link>
          
          <h1>Location de jeux</h1>
          <div className="nav-buttons">
          </div>
        </div>
        
        <div className="right-side">
          <Link to="/MesLocations"><img src={Trois} alt="Trois" className="nav-button" /></Link>
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<Accueil />} />
        <Route path="/MesLocations" element={<MesLocations />} />
      </Routes>
    </div>
  );
}
