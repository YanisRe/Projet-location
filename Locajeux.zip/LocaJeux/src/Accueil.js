import React, { useEffect, useState } from 'react';
import './App.css'; 

export default function JeuApp() {
  const [Jeux, setJeux] = useState([]);
  const [startIndex, setStartIndex] = useState(1);
  
  // cette fonction sera appelée lorsque l'utilisateur clique sur un Jeu pour le sélectionner
  const handleJeuClick = (Nom_Jeu) => {
    // On récupère le nom du jeu
    const jeuLink = `http://localhost:3306/api/td_location/${Nom_Jeu}`;

    //on récup la liste des liens du local storage
    const storedLinks = JSON.parse(localStorage.getItem('selectedJeuLinks')) || [];

    // On regarde si le lien est déjà dans la liste
    const isLinkAlreadySelected = storedLinks.includes(jeuLink);

    if (!isLinkAlreadySelected) {
      storedLinks.push(jeuLink);

      // Stockez la liste mise à jour dans le local storage
      localStorage.setItem('selectedJeuLinks', JSON.stringify(storedLinks));
    }
  };

  // On récupère les données des jeux
  useEffect(() => {
    const fetchJeuData = async () => {
      const jeuData = [];
      try {
        for (let i = startIndex; i <= startIndex + 3; i++) {
          const response = await fetch(`http://localhost:3306/api/td_location/${i}/`);
          if (!response.ok) {
            throw new Error('Failed to fetch data');
          }
          const data = await response.json();
          const id = data.id;
          const name = data.name;
          const imageUrl = data.sprites.other.dream_world.front_default;
          const types = data.types.map(typeObj => typeObj.type.name);
    
          jeuData.push({ name, imageUrl, types, id });
        }
    
        setJeux(jeuData);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchJeuData();
  }, [startIndex]);

  const loadNextJeu = () => {
    setStartIndex(startIndex + 3);
  };

  const loadBeforeJeu = () => {
    setStartIndex(startIndex - 3);
  };

  return (
    <div className='jeu-app'>
      <div className='jeu-list'>
        {Jeux.map((jeu, index) => (
          <div className="conteneur-jeu" key={index}>
            <h2>{jeu.id}</h2>
            <h1>{jeu.name}</h1>
            <img src={jeu.imageUrl} alt={jeu.name} class="image-du-jeu" />
            <p>Notes:</p>
            <div className='notes'>
            </div>
            <button className="codepen-button" onClick={() => handleJeuClick(jeu)}>
              <span>Louer le jeu</span>
            </button>
          </div>
        ))}
      </div>
      <div className="pagination">
        {startIndex >= 5 && <button className='box' onClick={loadBeforeJeu}>Précédent</button>}
        <button className="box" onClick={loadNextJeu}>Suivant</button>
      </div>
    </div>
  );
}
